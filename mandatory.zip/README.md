# Canvas Apps Design System
This guide is created for Power Platform Canvas App makers to use in order to provide a more usable and consistent online experience for internal users at Employment and Social Development Canada (ESDC).
[ Canvas Apps Design System home page](https://imit-solutions-esdc.github.io/Canvas-Apps-Design-System/).

# Système de conception d'applications Canvas
Ce guide est créé pour les <span lang="en">App makers</span> de Power Platform Canvas afin d'offrir une expérience en ligne plus utilisable et cohérente aux utilisateurs internes d'Emploi et Développement social Canada (EDSC).
Système de conception d'applications Canvas (a venir).
